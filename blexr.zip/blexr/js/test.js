jQuery(function($){ 
	   
	$('#filter').submit(function(){
		var filter = $('#filter');

		$.ajax({
			url:filter.attr('action'),
			data:filter.serialize(), // form data
			type:filter.attr('method'), // POST
			beforeSend:function(xhr){
				filter.find('button').text('Processing...'); 
			},
			success:function(data){
				filter.find('button').text('Apply filter'); 

				   var response=JSON.parse(data);
				 
				   $('#responsive').html(response["#table_value"]);

			}
		});
		return false;
	});

    $(document ).on('click', '.odds_sign', function() {

		var elem = $(this).text();

		if (elem == "+") {
            $(this).text("-");
			$(this).closest('.table_column').find('.table_column_inner_content').slideDown();

          } else {
			$(this).text("+");
			$(this).closest('.table_column').find('.table_column_inner_content').slideUp();

          }

   });


   $(document ).on('click', '.table_column_inner_content_odd span', function() {

	   var quote=$(this).text();

	   var  match=$(this).closest('.table_column').find('.table_column_inner_header .table_column_inner_match').text();

	   var better=$(this).closest('.table_column_inner_content_header').find('.table_column_inner_content_sites').text();

	 

	    let index = $(this).parent().children();
			index = index.index(this);
		
		if (index==0){
			odd=1;
		}	
		if (index==1){
			odd="X";
		}
		if (index==2){
			odd=2;
		}
		 
		
		id=match+ better+odd+quote;
		$exist_alredy=false;

		$('.my_ticket_table .my_ticket_column').each(function (){
			
			if (id==$(this).attr('id')){
                 $exist_alredy=true;
			}
			
		
		});

		if ($exist_alredy){

			alert("Alredy added on ticket!");

		}else{

			var html = "<div id='"+id+"' class='my_ticket_column'>";
			html += "<span class='ticket_match'>"+match+"</span>";
			html += "<span class='ticket_better'>"+better+"</span>";
			html += "<span class='ticket_odd'>"+odd+"</span>";
			html += "<span class='ticket_quote'>"+quote+"</span>";
			html += "<span class='ticket_remove'>-</span>";
			html +="</div>";
	 
			$(".my_ticket_table").append(html); 

/*
			var html_calculator = "<input class='odds' type='number' value='"+quote+"' placeholder='Enter Odds'>";
			
			$(".odds_holder").append(html_calculator); 

			var sum=$(".payout span").text();	

	            sum=sum * $(this).text();

		        $(".payout span").text(sum);   */

		}

	

   });


   $(document ).on('click', '.my_ticket_column .ticket_remove', function() {

	    $(this).closest('.my_ticket_column').remove();


   });



   $(document ).on('click', '.my_ticket_filter_sort .sign_sort', function() {
		  
		  var arlene1 = [];

		  var b= [];

	      $i=-1;
	
	     $('.my_ticket_table .my_ticket_column').each(function (){

			$i++;

		    arlene1[$i]= [$(this).attr('id'),$(this).find('.ticket_match').text(),$(this).find('.ticket_better').text(),$(this).find('.ticket_odd').text(), $(this).find('.ticket_quote').text()];

	     });



		 $number=$('.my_ticket_table').children().length-3;

		
	    var elem2 = $(this).text();

		if (elem2 == "+/-") {
			$(this).text("-/+");
			
			
            for ($i=0; $i<= $number-1; $i++){
				for ($j=$i+1; $j<= $number; $j++){

                      if (arlene1[$i][4]>arlene1[$j][4]){

						b=arlene1[$i];
						arlene1[$i]=arlene1[$j];
						arlene1[$j]=b;

					  }
				}
          


			}
			
          } else {
			$(this).text("+/-");

			for ($i=0; $i<= $number-1; $i++){
				for ($j=$i+1; $j<= $number; $j++){

                      if (arlene1[$i][4]<=arlene1[$j][4]){

						b=arlene1[$i];
						arlene1[$i]=arlene1[$j];
						arlene1[$j]=b;

					  }
				}
          


			}

		  }

		  $i=-1;
		  

		  $('.my_ticket_table .my_ticket_column').each(function (){

			 $i++;
			 
			 var html = "<div id='"+arlene1[$i][0]+"' class='my_ticket_column'>";
			html += "<span class='ticket_match'>"+arlene1[$i][1]+"</span>";
			html += "<span class='ticket_better'>"+arlene1[$i][2]+"</span>";
			html += "<span class='ticket_odd'>"+arlene1[$i][3]+"</span>";
			html += "<span class='ticket_quote'>"+arlene1[$i][4]+"</span>";
			html += "<span class='ticket_remove'>-</span>";
			html +="</div>";
	 
			

			 $(this).remove();

			 $(".my_ticket_table").append(html); 


	     });

   });


   $( "#search_ticket" ).keyup(function() {

		   $("#search_ticket").attr("value", $(this).val());
		   
		   var search1=$(this).val();

	      $('.my_ticket_table .my_ticket_column').each(function (){

			  
			   var value1=$(this).find('.ticket_match').text();

			   if (value1.indexOf(search1) >= 0){

				   $(this).css('display', 'flex');

			   }else{

				  $(this).css('display', 'none');

			   }

	      });


	});
	


$(document).ready(function() {
	$('.menu').change(function() {
	  var id = this.id;
	  var value = this.value;
	  if ($(this).css('display') == 'none') {
		$('.menu[data-parent="#' + id + '"]').css('display', 'none').change();
	  } else {
		$('.menu[data-parent="#' + id + '"]:not([data-target="' + value + '"])').css('display', 'none').change();
		$('.menu[data-parent="#' + id + '"][data-target="' + value + '"]').css('display', 'block').change();
	  }
	});
  });



//Decimal

 $(document ).on('click', '.add_ods', function() {

	var html_calculator = "<input class='odds new' type='number'  placeholder='Enter Odds'>";
		
	$(".odds_holder").append(html_calculator); 


 });

 $(document).on('keypress',function(e) {
    if(e.which == 13) {
       $("#sum").click();
    }
});




 $(document ).on('click', '#sum', function() {

	   var stake=$("#stake").val();

			sum=stake;
			

	   $('.odds_holder .odds').each(function (){

			 sum=sum*$(this).val();
 
	   });

	   $(".payout span").text(sum);

});




 $(document ).on('click', '.remove_value', function() {

	$("#stake").val("");

	$('.odds:not(:first)').each(function (){

		$(this).remove();
  
	 });

	 $(".odds:first").val("");

	 $(".payout span").text(0);

	

 });
 



//American

$(document ).on('click', '.add_ods_american', function() {

	var html_calculator = "<input class='odds_american new' type='number'  placeholder='Enter Odds'>";
		
	$(".odds_holder_american").append(html_calculator); 


 });

 $(document).on('keypress',function(e) {
    if(e.which == 13) {
       $("#sum_american").click();
    }
});

$(document ).on('click', '#sum_american', function() {

	var stake=$("#stake_american").val();

	    stake_american=stake;
		 

	$('.odds_holder_american .odds_american').each(function (){

		var odd_american_temp=$(this).val();

		if (odd_american_temp>=0){

			  odd_american=(odd_american_temp / 100) + 1; 
 
		 }else{
 
			 odd_american=(100 / ((-1)*odd_american_temp) ) + 1; 
 
		 }

		stake_american=stake_american * odd_american;

	});

	$(".payout_american span").text(stake_american);

});



$(document ).on('click', '.remove_value_american', function() {

	$("#stake_american").val("");

	$('.odds_american:not(:first)').each(function (){

		$(this).remove();
  
	 });

	 $(".odds_american:first").val("");

	 $(".payout_american span").text(0);

	

 });


//Fractal

$(document ).on('click', '.add_ods_fractal', function() {

	var html_calculator = "<div class='odds_holder_fractal_inner'><input class='odds_fractal_numerator' type='number' value='' placeholder='Enter Odds'> / <input class='odds_fractal_denominator' type='number' value='' placeholder='Enter Odds'></div>";
		
	$(".odds_holder_fractal").append(html_calculator); 


 });

 $(document).on('keypress',function(e) {
    if(e.which == 13) {
       $("#sum_fractal").click();
    }
});


$(document ).on('click', '#sum_fractal', function() {

	var stake=$("#stake_fractal").val();

	    stake_fractal=stake;
		 

	$('.odds_holder_fractal .odds_holder_fractal_inner').each(function (){

		var odd_numerator=$(this).find('.odds_fractal_numerator').val();

		var odd_denominator=$(this).find('.odds_fractal_denominator').val();

		     odd_fractal=(odd_numerator / odd_denominator ) + 1; 

			 stake_fractal=stake_fractal*odd_fractal;

	});

	$(".payout_fractal span").text(stake_fractal);

});


$(document ).on('click', '.remove_value_fractal', function() {

	$("#stake_fractal").val("");

	$('.odds_holder_fractal .odds_holder_fractal_inner:not(:first)').each(function (){

		$(this).remove();
  
	 });

	 $(".odds_holder_fractal .odds_holder_fractal_inner:first .odds_fractal_numerator").val("");

	 $(".odds_holder_fractal .odds_holder_fractal_inner:first .odds_fractal_denominator").val("");

	 $(".payout_fractal span").text(0);

	

 });












});


